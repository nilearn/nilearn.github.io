"""
Computing a connectome with sparse inverse covariance
=====================================================

This example constructs a functional connectome using the sparse inverse
covariance.

Note that the inverse covariance (or precision) contains values that can
be linked to *negated* partial correlations, so we negated it for
display.

.. admonition:: dataset

    This example uses the :ref:`MSDL atlas <msdl_atlas>`
    to extract time series
    from the :ref:`development fMRI dataset <development_dataset>`
    with the :class:`~nilearn.maskers.NiftiMapsMasker`.

    As the MSDL atlas comes with (x, y, z) :term:`MNI` coordinates
    for the different regions,
    we can visualize the matrix as a graph of interaction in a brain.
    To avoid having too dense a graph,
    we represent only the 20% edges with the highest values.
"""

# %%
# Retrieve the atlas and the data
# -------------------------------
from nilearn.datasets import fetch_atlas_msdl, fetch_development_fmri

atlas = fetch_atlas_msdl()

# %%
print(atlas.description.content)

# Loading atlas image and labels
atlas_filename = atlas.maps
labels = atlas.labels

# %%
# Loading the functional datasets
data = fetch_development_fmri(n_subjects=1)

# %%
# print basic information on the dataset
print(f"First subject functional nifti images (4D) are at: {data.func[0]}")

# %%
# Extract time series
# -------------------
from nilearn.maskers import NiftiMapsMasker

masker = NiftiMapsMasker(
    maps_img=atlas_filename,
    standardize_confounds=True,
    standardize="zscore_sample",
    memory="nilearn_cache",
    memory_level=1,
    verbose=1,
)

time_series = masker.fit_transform(data.func[0], confounds=data.confounds)

# %%
# Compute the sparse inverse covariance
# -------------------------------------
from sklearn.covariance import GraphicalLassoCV

estimator = GraphicalLassoCV(verbose=True)
estimator.fit(time_series)

# %%
# Visualization: covariance
# -------------------------
# The covariance can be found at ``estimator.covariance_``.
# We plot it along with its connectome graph.
from nilearn.plotting import (
    plot_connectome,
    plot_matrix,
    show,
    view_connectome,
)

plot_matrix(
    estimator.covariance_,
    labels=labels,
    figure=(9, 7),
    vmax=1,
    vmin=-1,
    title="Covariance",
)

coords = atlas.region_coords

plot_connectome(
    estimator.covariance_, coords, title="Covariance", edge_threshold="80%"
)

show()


# %%
# Visualization: sparse inverse covariance
# ----------------------------------------
# We negate the precision to get partial correlations.
plot_matrix(
    -estimator.precision_,
    labels=labels,
    figure=(9, 7),
    vmax=1,
    vmin=-1,
    title="Sparse inverse covariance",
)

plot_connectome(
    -estimator.precision_,
    coords,
    title="Sparse inverse covariance",
    edge_threshold="80%",
)

show()

# %%
# 3D visualization in a web browser
# ---------------------------------
# An alternative to :func:`~nilearn.plotting.plot_connectome` is to use
# :func:`~nilearn.plotting.view_connectome` that gives more interactive
# visualizations in a web browser.
# See :ref:`interactive-connectome-plotting` for more details.


view = view_connectome(-estimator.precision_, coords, edge_threshold="80%")

# In a notebook, if ``view`` is the output of a cell, it will
# be displayed below the cell
view

# %%

# uncomment this to open the plot in a web browser:
# view.open_in_browser()

# sphinx_gallery_dummy_images=4
